const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));

// Route to display the first form (/form)
app.get('/form', (req, res) => {
  res.send(`
    <html>
    <head>
      <title>Product Form</title>
    </head>
    <body>
      <h1>Product Form</h1>
      <form action="/form" method="POST">
        <label for="productid">Product ID:</label>
        <input type="text" id="productid" name="productid" required><br><br>

        <label for="productName">Product Name:</label>
        <input type="text" id="productName" name="productName" required><br><br>

        <label for="price">Price:</label>
        <input type="number" id="price" name="price" required><br><br>

        <button type="submit">Submit</button>
      </form>
    </body>
    </html>
  `);
});

// Handle form submission for /form
app.post('/form', (req, res) => {
  const { productid, productName, price } = req.body;

  if (!productid || !productName || !price) {
    return res.status(400).send('All fields are required.');
  }

  console.log(`Product ID: ${productid}, Product Name: ${productName}, Price: ${price}`);
  res.send('Product information submitted successfully.');
});

// Route to display the second form (/submit)
app.get('/submit', (req, res) => {
  res.send(`
    <html>
    <head>
      <title>Submit Form</title>
    </head>
    <body>
      <h1>Submit Form</h1>
      <form action="/submit" method="POST">
        <label for="productid">Product ID:</label>
        <input type="text" id="productid" name="productid" required><br><br>

        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity" required><br><br>

        <button type="submit">Submit</button>
      </form>
    </body>
    </html>
  `);
});

// Handle form submission for /submit
app.post('/submit', (req, res) => {
  const { productid, quantity } = req.body;

  if (!productid || !quantity) {
    return res.status(400).send('All fields are required.');
  }

  console.log(`Product ID: ${productid}, Quantity: ${quantity}`);
  res.send('Form submitted successfully.');
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
