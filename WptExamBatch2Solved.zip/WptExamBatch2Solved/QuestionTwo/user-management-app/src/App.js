import React, { useState } from "react";
// import "bootstrap/dist/css/bootstrap.min.css";
import UserManagement from './UserManagement.js'

function App() {
  return (
    <div className="container mt-5">
    <h1 className="text-center mb-4">User Management App</h1>
    <UserManagement />
  </div>
  );
}

export default App;
