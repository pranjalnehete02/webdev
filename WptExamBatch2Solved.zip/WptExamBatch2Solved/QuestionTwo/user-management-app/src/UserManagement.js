import React, { useState } from "react";
// import "bootstrap/dist/css/bootstrap.min.css";
import UserForm from './UserForm.js'

function UserManagement() {
    const [users, setUsers] = useState([
      { id: 1, firstName: "Jack", lastName: "Jonathan", email: "xyz@gmail.com" },
    ]);
    const [editingUser, setEditingUser] = useState(null);
  
    const addUser = (user) => setUsers([...users, { ...user, id: Date.now() }]);
  
    const updateUser = (updatedUser) =>
      setUsers(users.map((user) => (user.id === updatedUser.id ? updatedUser : user)));
  
    const deleteUser = (id) => setUsers(users.filter((user) => user.id !== id));
  
    return (
      <div>
        <button
          className="btn btn-primary mb-3"
          onClick={() => setEditingUser({ id: null, firstName: "", lastName: "", email: "" })}
        >
          Add User
        </button>
  
        <table className="table table-bordered">
          <thead className="thead-dark">
            <tr>
              <th>User First Name</th>
              <th>User Last Name</th>
              <th>User Email</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.firstName}</td>
                <td>{user.lastName}</td>
                <td>{user.email}</td>
                <td>
                  <button
                    className="btn btn-sm btn-warning mr-2"
                    onClick={() => setEditingUser(user)}
                  >
                    Update
                  </button>
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => deleteUser(user.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
  
        {editingUser && (
          <UserForm
            user={editingUser}
            onSave={(user) => {
              user.id ? updateUser(user) : addUser(user);
              setEditingUser(null);
            }}
            onCancel={() => setEditingUser(null)}
          />
        )}
      </div>
    );
  }
  export default UserManagement;