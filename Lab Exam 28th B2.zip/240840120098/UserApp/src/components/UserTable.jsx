import React from "react";
import { Link } from "react-router-dom";

const UserTable = ({ users }) => {
  const handleDelete = (id) => {
    
    console.log(`Delete user with ID: ${id}`);
    
  };

  return (
    <div className="table-responsive mt-4">
      <table className="table table-striped table-bordered">
        <thead className="table-dark">
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.length > 0 ? (
            users.map((user) => (
              <tr key={user.id}>
                <td>{user.firstname}</td>
                <td>{user.lastname}</td>
                <td>{user.email}</td>
                <td>
                  {/* View Button */}
                  <Link
                    to={`/view-user/${user.id}`}
                    className="btn btn-info btn-sm mx-1"
                  >
                    View
                  </Link>
                  {/* Edit Button */}
                  <Link
                    to={`/edit-user/${user.id}`}
                    className="btn btn-warning btn-sm mx-1"
                  >
                    Edit
                  </Link>
                  {/* Delete Button */}
                  <button
                    className="btn btn-danger btn-sm mx-1"
                    onClick={() => handleDelete(user.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" className="text-center">
                No users available
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default UserTable;
