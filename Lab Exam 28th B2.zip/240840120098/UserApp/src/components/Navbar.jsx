import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <span className="navbar-brand">User Management App</span>
        <Link to="/add-user" className="btn btn-primary">
          Add User
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
