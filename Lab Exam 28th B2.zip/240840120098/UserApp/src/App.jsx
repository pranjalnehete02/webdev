import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes, useNavigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import UserList from "./components/UserList";
import UserForm from "./components/UserForm";
import 'bootstrap/dist/css/bootstrap.min.css';


const App = () => {
  
  const [users, setUsers] = useState([
    { id: 1, firstname: "Hitesh", lastname: "Talesra", email: "hitesh@exam.com" },
    { id: 2, firstname: "Bobby", lastname: "Patel", email: "bobby@exam.com" },
  ]);

  
  const addUser = (newUser) => {
    setUsers([...users, { id: users.length + 1, ...newUser }]);
  };

  
  const updateUser = (id, updatedUser) => {
    setUsers(users.map(user => (user.id === id ? { ...user, ...updatedUser } : user)));
  };

  
  const deleteUser = (id) => {
    setUsers(users.filter(user => user.id !== id));
  };

  return (
    <Router>
      <Navbar />
      <div className="container mt-4">
        <Routes>
          <Route
            path="/"
            element={<UserList users={users} deleteUser={deleteUser} />}
          />
          <Route
            path="/add-user"
            element={<UserForm addUser={addUser} />}
          />
          <Route
            path="/edit-user/:id"
            element={<UserForm users={users} updateUser={updateUser} />}
          />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
