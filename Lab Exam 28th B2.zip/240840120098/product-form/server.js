const express = require('express');
const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));


app.use(express.static('public'));


app.get('/form', (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Product Form</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            padding: 20px;
          }
          .form-container {
            width: 300px;
            margin: 0 auto;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
          }
          label, input {
            width: 100%;
            margin: 8px 0;
            padding: 8px;
            box-sizing: border-box;
          }
          button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
          }
          button:hover {
            background-color: #0056b3;
          }
        </style>
      </head>
      <body>
        <div class="form-container">
          <h2>Enter Product Details</h2>
          <form action="/submit" method="POST">
            <label for="productid">Product ID:</label>
            <input type="text" id="productid" name="productid" required />

            <label for="productname">Product Name:</label>
            <input type="text" id="productname" name="productname" required />

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" required />

            <button type="submit">Submit</button>
          </form>
        </div>
      </body>
    </html>
  `);
});


app.post('/submit', (req, res) => {
  const { productid, productname, price } = req.body;


  if (!productid || !productname || !price) {
    return res.status(400).send('All fields are required.');
  }


  console.log(`Product ID: ${productid}`);
  console.log(`Product Name: ${productname}`);
  console.log(`Price: ${price}`);


  res.send(`
    <html>
      <body>
        <h2>Form Submitted Successfully!</h2>
        <p>Product ID: ${productid}</p>
        <p>Product Name: ${productname}</p>
        <p>Price: ${price}</p>
        <a href="/form">Go back to form</a>
      </body>
    </html>
  `);
});


app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
